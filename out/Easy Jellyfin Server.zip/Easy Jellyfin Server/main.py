import os

# The decky plugin module is located at decky-loader/plugin
# For easy intellisense checkout the decky-loader code repo
# and add the `decky-loader/plugin/imports` path to `python.analysis.extraPaths` in `.vscode/settings.json`
import decky
import asyncio
import socket
import subprocess
from pathlib import Path
import re

APP_ID = "org.jellyfin.JellyfinServer"

class Plugin:
    _status = False

    async def jellyfin_status(self):
        return self._status

    async def start_jellyfin(self):
        self._status = True
        decky.logger.info("Voy a lanzar el evento")
        await self.server_running()

    async def stop_jellyfin(self):
        self._status = False

    async def get_server_address(self):
        ip = self.get_local_ip()
        port = await self.get_jellyfin_port()

        return f'{ip}:{port}'

    def get_local_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        except:
            ip = "127.0.0.1"
        finally:
            s.close()

        return ip

    async def get_flatpak_app_path(self):
        result = await self.run_cmd(f"flatpak info --show-location {APP_ID}")
        if result["returncode"] != 0:
            raise RuntimeError(
                f'flatpak info falló:\n{result["stderr"]}'
            )
        return Path(result["stdout"].strip())

    def get_jellyfin_config_path(self):
        app_path = self.get_flatpak_app_path()
        return app_path / "config" / "jellyfin" / "system.xml"

    async def get_jellyfin_port(self):
        try:
            config_path = self.get_jellyfin_config_path()
            decky.logger.info(config_path)
            text = Path(config_path).read_text()
            decky.logger.info(text)

            match = re.search(r"<HttpServerPortNumber>(\d+)</HttpServerPortNumber>", text)
            decky.logger.info("found")
            if match:
                return match.group(1)
        except Exception as e:
            decky.logger.info("ups")
            decky.logger.info(e)
            pass

        return "9096"

    async def server_running(self):
        await asyncio.sleep(1)
        decky.logger.info("Voy a lanzar el evento de server_running")
        await decky.emit("server_running_event", "¡Server is on!")

    async def run_cmd(self, cmd: str):
        xdg_runtime_dir = os.environ.get("XDG_RUNTIME_DIR")

        if not xdg_runtime_dir:
            uid = os.getuid()
            xdg_runtime_dir = f"/run/user/{uid}"

        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env={
                **os.environ,
                "XDG_RUNTIME_DIR": xdg_runtime_dir,
            },
        )

        stdout, stderr = await proc.communicate()

        return {
            "returncode": proc.returncode,
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
        }
    # A normal method. It can be called from the TypeScript side using @decky/api.
    async def add(self, left: int, right: int) -> int:
        return left + right

    async def long_running(self):
        await asyncio.sleep(1)
        # Passing through a bunch of random data, just as an example
        await decky.emit("timer_event", "Hello from the backend!", True, 2)

    # Asyncio-compatible long-running code, executed in a task when the plugin is loaded
    async def _main(self):
        self.loop = asyncio.get_event_loop()
        decky.logger.info("Hello World!")

    # Function called first during the unload process, utilize this to handle your plugin being stopped, but not
    # completely removed
    async def _unload(self):
        decky.logger.info("Goodnight World!")
        pass

    # Function called after `_unload` during uninstall, utilize this to clean up processes and other remnants of your
    # plugin that may remain on the system
    async def _uninstall(self):
        decky.logger.info("Goodbye World!")
        pass

    async def start_timer(self):
        self.loop.create_task(self.long_running())

    # Migrations that should be performed before entering `_main()`.
    async def _migration(self):
        decky.logger.info("Migrating")
        # Here's a migration example for logs:
        # - `~/.config/decky-template/template.log` will be migrated to `decky.decky_LOG_DIR/template.log`
        decky.migrate_logs(os.path.join(decky.DECKY_USER_HOME,
                                               ".config", "decky-template", "template.log"))
        # Here's a migration example for settings:
        # - `~/homebrew/settings/template.json` is migrated to `decky.decky_SETTINGS_DIR/template.json`
        # - `~/.config/decky-template/` all files and directories under this root are migrated to `decky.decky_SETTINGS_DIR/`
        decky.migrate_settings(
            os.path.join(decky.DECKY_HOME, "settings", "template.json"),
            os.path.join(decky.DECKY_USER_HOME, ".config", "decky-template"))
        # Here's a migration example for runtime data:
        # - `~/homebrew/template/` all files and directories under this root are migrated to `decky.decky_RUNTIME_DIR/`
        # - `~/.local/share/decky-template/` all files and directories under this root are migrated to `decky.decky_RUNTIME_DIR/`
        decky.migrate_runtime(
            os.path.join(decky.DECKY_HOME, "template"),
            os.path.join(decky.DECKY_USER_HOME, ".local", "share", "decky-template"))
